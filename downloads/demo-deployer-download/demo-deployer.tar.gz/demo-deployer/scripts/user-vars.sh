############################################
# OpenShift Environment Variables
############################################
CLUSTER_NAME=""
BASE_DOMAIN=""

############################################
# APIC - Drop While It's Hot API 
############################################
DEPLOY_APIC_DWH="true"