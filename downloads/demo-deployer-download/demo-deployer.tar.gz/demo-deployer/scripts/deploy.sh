#!/bin/bash
############################################################
#Author           : Dave Krier, Jeff Imholz
#Author email     : dakrier@us.ibm.com, jimholz@us.ibm.com
#Original Date    : 2023-05-08
#Initial Version  : v2023-05-8
############################################################
#  Deploy Asset in OpenShift
############################################################

############################################################
#Setup Environment
############################################################

SCRIPTS_DIR="$( cd "$( dirname "$0" )" && pwd )"

if [ ! -d "${SCRIPTS_DIR}/../log" ] ; then
   mkdir ${SCRIPTS_DIR}/../log
fi

if [ ! -d "${SCRIPTS_DIR}/../demos" ] ; then
   mkdir ${SCRIPTS_DIR}/../demos
fi

LOG_DIR="$( cd ${SCRIPTS_DIR}/../log && pwd)"
DEMOS_DIR="$( cd ${SCRIPTS_DIR}/../demos && pwd)"

source ${SCRIPTS_DIR}/sourced-scripts/functions.sh &> /dev/null
source ${SCRIPTS_DIR}/sourced-scripts/vars.sh &> /dev/null
source ${SCRIPTS_DIR}/sourced-scripts/demo-deployment-scripts/apic-dwh-api.sh &> /dev/null
source ${SCRIPTS_DIR}/user-vars.sh &> /dev/null



#############################################################
# Main
#############################################################

validateInput

validateOCPAccess

verifyRegistryRoute

loginRegistry

### Deploy Demos

if [ "${DEPLOY_APIC_DWH}" == "true" ]; then
    deployDemoApicDwh
fi    

