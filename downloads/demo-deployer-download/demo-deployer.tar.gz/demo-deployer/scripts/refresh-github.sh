#!/bin/bash
FOUND_GIT_COMMAND=`git --version 2> /dev/null | grep -c "git version"`
if [ ${FOUND_GIT_COMMAND} -eq  0 ]; then
  echo "Missing git please install and run again"
  exit 9
fi
OS=`find /etc | grep -c os-release` &> /dev/null
if [ "${OS}" == 1 ]; then
  if [  -d "/data/demo-deployer" ]; then
     mkdir /data/dd-temp
     mv /data/demo-deployer/{tmp,log,certs,demos} /data/dd-temp &> /dev/null
     rm -fR /data/demo-deployer &> /dev/null
     cd /data
     git clone https://${GITHUB_IBM_USERNAME}:${GITHUB_IBM_TOKEN}@github.ibm.com/Daffy-Internal/demo-deployer.git;
     chmod -fR 755 /data/demo-deployer
     mv /data/dd-temp/{tmp,log,certs,demos} /data/demo-deployer &> /dev/null
     chmod -fR 755 /data/demo-deployer
     rm -fR /data/dd-temp &> /dev/null
     cd /data/demo-deployer
     echo ""
     echo "Your code has been refreshed with the github repository" 
   fi
fi
