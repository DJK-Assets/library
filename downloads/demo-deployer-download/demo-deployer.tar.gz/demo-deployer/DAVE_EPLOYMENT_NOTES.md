# Useful Documentation

How to connect and push image to OCP
https://all.docs.genesys.com/PrivateEdition/Current/PEGuide/OCR

## SCP with ssh key

https://www.techrepublic.com/article/how-to-use-secure-copy-with-ssh-key-authentication/

## Deployment Notes. 

wget http://get.daffy-installer.com/demo-deployer-download/demo-deployer.tar.gz

## Deployment from Dave's local machine 

```
cd /Users/dakrier
cp -R /Users/dakrier/code/github_projects/demo-deployer .
```

Create the tar.gz file

```
tar czf demo-deployer.tar.gz ./demo-deployer
```

Copy the tar file to the Daffy Util Server 

```
scp -i ~/.ssh/dave-ssh-key.priv demo-deployer.tar.gz root@169.62.193.244:/var/www/html/demo-deployer-download/demo-deployer.tar.gz
```

```
rm -fR /Users/dakrier/demo-deployer
rm /Users/dakrier/demo-deployer.tar.gz
```

## Download and Install script link. 

```
wget http://get.daffy-installer.com/download-scripts/demo-deployer-init.sh; chmod 755 demo-deployer-init.sh;./demo-deployer-init.sh
```