# demo-deployer
Scripts for deployment of demo applications into OpenShift