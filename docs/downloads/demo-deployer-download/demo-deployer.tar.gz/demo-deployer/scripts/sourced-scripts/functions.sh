#!/bin/bash
############################################################
#Author           : Dave Krier, Jeff Imholz
#Author email     : dakrier@us.ibm.com, jimholz@us.ibm.com
#Original Date    : 2023-05-08
#Initial Version  : v2023-05-8
############################################################
#  This script is surced by the deploy.sh script and is not intended to be executed. 
############################################################

#############################################################
# Functions
#############################################################
validateInput()
{
    if [ "${CLUSTER_NAME}" == "" ]; then
        echo "${RED_TEXT}###########################################################################################"
        echo "To run this script, you must configure the user-vars.sh" 
        echo "###########################################################################################${RESET_TEXT}"
        exit 0
    fi

    case ${1} in
    --*|help)
        echo "${RED_TEXT}###########################################################################################"
        echo "To run this script, you must configure the user-vars.sh" 
        echo "###########################################################################################${RESET_TEXT}"
        exit 0
        ;;
    esac

}

validateOCPAccess()
{
  printHeaderMessage "Validate OCP Access"
  OC_CLUSTER_ACCESS=`timeout 30 oc get nodes 2> /dev/null  | grep -c Ready`
    if [ "${OC_CLUSTER_ACCESS}" == 0 ] ;then
       echo "${ICON_WAITING_USER_INPUT}Please login to your cluster web console and copy/paste the oc admin login command below:"
       read -p "" OC_ADMIN_TOKEN_COMMAND
       if [[ ${OC_ADMIN_TOKEN_COMMAND} == oc* ]]; then
          ${OC_ADMIN_TOKEN_COMMAND}
       fi
       if [ "${VALIDATE_OCP_ACCESS_RETRY}" == "false" ] ; then
         VALIDATE_OCP_ACCESS_RETRY="true"
         validateOCPAccess
       else 
       	 echo "${RED_TEXT}${ICON_FAIL}${RESET_TEXT} Unable to successfully log into the OpenShift Cluster"
       	 forceExit
       fi
   else
       echo "${BLUE_TEXT}${ICON_SUCCESS} PASSED ${RESET_TEXT} Access to cluster via oc command${RESET_TEXT}"
   fi

}

verifyRegistryRoute(){
  printHeaderMessage "Precheck if the route is defined"
  ROUTE_DEFINED=`oc get route default-route -n openshift-image-registry --template='{{ .spec.host }}' | grep -c default-route-openshift-image-registry.apps.${CLUSTER_NAME}.${BASE_DOMAIN}`

  if [ "${ROUTE_DEFINED}" != 1 ]; then
    echo "${YELLOW_TEXT}${ICON_WARNING}${RESET_TEXT} Image Registry route is not enabled"
    echo ""
    enableRegistryRoute
  else
    echo "${BLUE_TEXT}${ICON_SUCCESS} PASSED${RESET_TEXT} Image Registry route is enabled"
  fi
}

enableRegistryRoute()
{
  printHeaderMessage "Enabling the default route for OpenShift registry"
  oc patch configs.imageregistry.operator.openshift.io/cluster --patch '{"spec":{"defaultRoute":true}}' --type=merge
  ROUTE_DEFINED=`oc get route default-route -n openshift-image-registry --template='{{ .spec.host }}' | grep -c default-route-openshift-image-registry.apps.${CLUSTER_NAME}.${BASE_DOMAIN}`
  if [ "${ROUTE_DEFINED}" != 1 ]; then
    echo "${RED_TEXT}${ICON_FAIL}${RESET_TEXT} Image Registry route is not enabled. Exiting now as Demo's require this"
    forceExit
  else
    echo "${BLUE_TEXT}${ICON_SUCCESS} PASSED${RESET_TEXT} Image Registry route is enabled"
  fi
}


configureIngressCert()
{
  printHeaderMessage "Configuring Ingress Cert for Registry Login"
  AUTH_POD_ID=`oc get po -n openshift-authentication | awk 'NR==2{ print $1 }'`

  oc rsh -n openshift-authentication ${AUTH_POD_ID} cat /run/secrets/kubernetes.io/serviceaccount/ca.crt > ~/ingress-ca.crt
 
  cp /root/ingress-ca.crt /usr/local/share/ca-certificates

  update-ca-certificates > /dev/null 2>&1
}

loginRegistry() 
{
  printHeaderMessage "Attempting OpenShift Registry Login with Podman"
  AUTH_TOKEN=`oc whoami -t`
  LOGIN_SUCCESS=`podman login -u admin -p ${AUTH_TOKEN} default-route-openshift-image-registry.apps.${CLUSTER_NAME}.${BASE_DOMAIN} 2>&1 | grep -c Succeeded`
  if [ "${LOGIN_SUCCESS}" == 1 ] ; then
  	echo "${BLUE_TEXT}${ICON_SUCCESS} PASSED${RESET_TEXT} Login Succeeded"
  	echo ""
  else 
  	echo "${YELLOW_TEXT}${ICON_WARNING}${RESET_TEXT} First Attempt - Login Failed - Inspecting error to see if it can be fixed "
  	LOGIN_CERT=`podman login -u admin -p ${AUTH_TOKEN} default-route-openshift-image-registry.apps.${CLUSTER_NAME}.${BASE_DOMAIN} 2>&1 | grep -c x509`
    echo ""
    if [ "${LOGIN_CERT}" == 1 ] ; then
    	echo "${YELLOW_TEXT}${ICON_WRENCH}${RESET_TEXT} Certificate needs to be configured!"
    	configureIngressCert
    	loginRegistry
    else 
    	podman login -u admin -p ${AUTH_TOKEN} default-route-openshift-image-registry.apps.${CLUSTER_NAME}.${BASE_DOMAIN}
    	echo "${RED_TEXT}${ICON_FAIL}${RESET_TEXT} Failed log into the registry with podman"
    	forceExit
    fi
  fi
}

printHeaderMessage()
{
 echo ""
  if [  "${#2}" -ge 1 ] ;then
      echo "${2}${1}"
  else
      echo "${BLUE_TEXT}${1}"
  fi
  echo "################################################################${RESET_TEXT}"
  sleep 1
}

forceExit()
{
  echo ""
  echo ""
  echo "${RED_TEXT}${ICON_VERY_BAD_FAIL} Something bad happened. Exiting Script!!!!!!!${RESET_TEXT}"
  echo ""
  echo ""
  exit 99
}
