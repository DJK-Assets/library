
#############################################################
# Drop it While it's Hot - Demo Deployment Script
#############################################################
#### Override VARS####
APIC_DWH_NAMESPACE="default"


deployDemoApicDwh(){
    printHeaderMessage "Deploying Drop it While it's Hot API to OpenShift"
    cd ${DEMOS_DIR}

    IMAGE_REGISTRY=`oc get route -n openshift-image-registry | grep image-registry | awk '{print $2}'`

    wget http://get.daffy-installer.com/demo-downloads/dropwhilehot.tar.gz

    ## If download didn't work EXIT with Error    
    if [ ! -f dropwhilehot.tar.gz ]; then
        echo "${RED_TEXT}Failed to download the demo tar file, unable to continue:"
        forceExit
    fi
    echo "${BLUE_TEXT}${ICON_SUCCESS} PASSED${RESET_TEXT} Downloaded Demo Tar"
    echo ""
    
    ## Downlaod was successful - Exapand and move dir
    tar xvf dropwhilehot.tar.gz &> /dev/null

    rm -rf dropwhilehot.tar.gz

    cd ${DEMOS_DIR}/drop_while_hot

    ## Build the image
    podman build -t ${IMAGE_REGISTRY}/${APIC_DWH_NAMESPACE}/dropwhilehotapi:1.0 . > ${LOG_DIR}/podman_build_execution.log 2>&1
    PODMAN_BUILD=`cat ${LOG_DIR}/podman_build_execution.log | grep -c Successfully`

    if [ "${PODMAN_BUILD}" == 1 ]; then
        echo "${BLUE_TEXT}${ICON_SUCCESS} PASSED${RESET_TEXT} Podman Build Complete"
        echo ""
    else
        echo "${RED_TEXT}${ICON_FAIL}${RESET_TEXT} Podman Build Error"
        echo ""
        forceExit
    fi    

    ## Push the image
    podman push ${IMAGE_REGISTRY}/${APIC_DWH_NAMESPACE}/dropwhilehotapi:1.0 --tls-verify=false > ${LOG_DIR}/podman_push_execution.log 2>&1
    PODMAN_PUSH=`cat ${LOG_DIR}/podman_push_execution.log | grep -c Error`

    if [ "${PODMAN_PUSH}" != 0 ]; then
        echo "${RED_TEXT}${ICON_FAIL}${RESET_TEXT} Podman Push Failed"
        echo ""
        forceExit
    else
        echo "${BLUE_TEXT}${ICON_SUCCESS} PASSED${RESET_TEXT} Podman Push Complete"
        echo "${BLUE_TEXT}INFO ${RESET_TEXT} $IMAGE_REGISTRY  <-- Image Repository "
        echo ""
    fi

# Deploy YAML for OpenShift Deployment

cat <<EOF | oc apply -f -
apiVersion: apps/v1
kind: Deployment
metadata:
  name: dropwhilehotapi-deployment
  namespace: ${APIC_DWH_NAMESPACE}
spec:
  selector:
    matchLabels:
      app: dropwhilehotapi
  replicas: 1
  template:
    metadata:
      labels:
        app: dropwhilehotapi
    spec:
      containers:
        - name: dropwhilehotapi
          image: >-
            image-registry.openshift-image-registry.svc:5000/${APIC_DWH_NAMESPACE}/dropwhilehotapi:1.0
          ports:
            - containerPort: 3000
EOF

# Deploy YAML for OpenShift Service
sleep 5

cat <<EOF | oc apply -f -
apiVersion: v1
kind: Service
metadata:
  name: dropwhilehotapi-service
  namespace: ${APIC_DWH_NAMESPACE}
spec:
  selector:
    app: dropwhilehotapi
  ports:
    - name: web
      protocol: TCP
      port: 3001
      targetPort: 3000
EOF

# Deploy YAML for OpenShift Route
sleep 5

cat <<EOF | oc apply -f -
kind: Route
apiVersion: route.openshift.io/v1
metadata:
  name: dropwhilehot-route
  namespace: ${APIC_DWH_NAMESPACE}
spec:
  host: dropwhilehot-route-default.apps.${CLUSTER_NAME}.${BASE_DOMAIN}
  to:
    kind: Service
    name: dropwhilehotapi-service
    weight: 100
  port:
    targetPort: web
  wildcardPolicy: None
EOF

sleep 5
echo ""

ROUTE_DEPLOYED=`oc get route dropwhilehot-route -n ${APIC_DWH_NAMESPACE} | grep -c "not found"`

if [ "${ROUTE_DEPLOYED}" != "0" ]; then
    echo "${RED_TEXT}${ICON_FAIL}${RESET_TEXT} Deploy Failed"
    echo ""
    forceExit
else
    echo "${BLUE_TEXT}${ICON_SUCCESS} PASSED${RESET_TEXT} Demo Deployed"
    echo "URL to access your demo API:....http://dropwhilehot-route-default.apps.${CLUSTER_NAME}.${BASE_DOMAIN}/"
    echo ""
    echo "Demo script documentation:......https://pages.github.ibm.com/Daffy-Internal/demo-deployer-doc/demos/apic/dwh/dwh-restapi/"
fi
}