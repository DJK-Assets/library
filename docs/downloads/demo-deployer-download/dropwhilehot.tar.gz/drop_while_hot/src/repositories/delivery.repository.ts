import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDeliveryDataSource} from '../datasources';
import {Delivery, DeliveryRelations} from '../models';

export class DeliveryRepository extends DefaultCrudRepository<
  Delivery,
  typeof Delivery.prototype.id,
  DeliveryRelations
> {
  constructor(
    @inject('datasources.db_delivery') dataSource: DbDeliveryDataSource,
  ) {
    super(Delivery, dataSource);
  }
}
