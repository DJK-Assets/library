import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbQuoteDataSource} from '../datasources';
import {Quote, QuoteRelations} from '../models';

export class QuoteRepository extends DefaultCrudRepository<
  Quote,
  typeof Quote.prototype.id,
  QuoteRelations
> {
  constructor(
    @inject('datasources.db_quote') dataSource: DbQuoteDataSource,
  ) {
    super(Quote, dataSource);
  }
}
