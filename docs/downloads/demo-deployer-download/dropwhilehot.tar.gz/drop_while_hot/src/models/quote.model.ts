import {Entity, model, property} from '@loopback/repository';

@model()
export class Quote extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  customerName: string;

  @property({
    type: 'number',
    required: true,
  })
  cost: number;

  @property({
    type: 'date',
    required: true,
  })
  date: string;

  @property({
    type: 'string',
    required: true,
  })
  email: string;

  @property({
    type: 'string',
    required: true,
  })
  address: string;

  constructor(data?: Partial<Quote>) {
    super(data);
  }
}

export interface QuoteRelations {
  // describe navigational properties here
}

export type QuoteWithRelations = Quote & QuoteRelations;
