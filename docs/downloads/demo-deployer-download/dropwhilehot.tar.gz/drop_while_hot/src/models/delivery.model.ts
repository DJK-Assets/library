import {Entity, model, property} from '@loopback/repository';

@model()
export class Delivery extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  customerName: string;

  @property({
    type: 'string',
    required: true,
  })
  address: string;

  @property({
    type: 'number',
    required: true,
  })
  quoteId: number;

  @property({
    type: 'date',
    required: true,
  })
  date: string;


  constructor(data?: Partial<Delivery>) {
    super(data);
  }
}

export interface DeliveryRelations {
  // describe navigational properties here
}

export type DeliveryWithRelations = Delivery & DeliveryRelations;
